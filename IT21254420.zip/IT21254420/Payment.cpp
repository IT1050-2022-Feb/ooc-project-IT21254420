#include "stdafx.h"
#include "Payment.h"
#include <cstring>
#include <iostream>
using namespace std;

Payment::Payment()
{
	payID = 1001;
	amount = 1500.0;
	strcpy_s(payDate, "2022-09-01");
}

Payment::Payment(double pay)
{
}

Payment::Payment(int p_ID, double pAmount, char p_Date[])
{
	payID = p_ID;
	amount = pAmount;
	strcpy_s(payDate, p_Date);
}

void Payment::Display()
{
}

void Payment::DisplayPaymentDetails()
{
	cout << "Payment ID : " << payID << endl
		<< "Amount : " << amount << endl
		<< "Pay Date : " << payDate << endl;
}


Payment::~Payment()
{
	cout << "Destructed" << endl;
}
