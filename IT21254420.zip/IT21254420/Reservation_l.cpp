#include "stdafx.h"
#include "Reservation_l.h"
#include <cstring>
#include <iostream>
using namespace std;


Reservation_l::Reservation_l()
{
	pay[0] = new Payment(1800.00);
	pay[1] = new Payment(1500.00);
	strcpy_s(reservationID, "898");
	strcpy_s(reservationDate, "2022.09.19");
	labNumber = 10;
}

Reservation_l::Reservation_l(double pay1, double pay2, char r_ID[], char r_Date[], int labNO)
{
	pay[0] = new Payment(pay1);
	pay[1] = new Payment(pay2);
	strcpy_s(reservationID, r_ID);
	strcpy_s(reservationDate, r_Date);
	labNumber = labNO;

}

void Reservation_l::DisplayReservationDetails()
{
	for (int i = 0; i < SIZE; i++) {
		pay[i]->Display();
	}
}


Reservation_l::~Reservation_l()
{
	cout << "Reservation close" << endl;
	for (int i = 0; i<SIZE; i++)
		delete pay[i];
	cout << "The End" << endl;
}
