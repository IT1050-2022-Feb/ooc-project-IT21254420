#include "stdafx.h"
#include "Feedback.h"
#include <cstring>
#include <iostream>
using namespace std;


Feedback::Feedback()
{
	feedbackNo = 1010;
	strcpy_s(feedbackDescription, "Exellent");
}

Feedback::Feedback(int f_No, char f_Desc[])
{
	feedbackNo = f_No;
	strcpy_s(feedbackDescription, f_Desc);
}


void Feedback::DisplayFeedback()
{
	cout << "Feedback Number : " << feedbackNo << endl
		<< "Feedback Description : " << feedbackDescription << endl;
}

Feedback::~Feedback()
{
	cout << "Destructed" << endl;
}
