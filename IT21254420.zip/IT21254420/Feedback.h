#pragma once
class Feedback
{
private:
	int feedbackNo;
	char feedbackDescription[20];

public:
	Feedback();
	Feedback(int f_No, char f_Desc[]);
	void DisplayFeedback();
	~Feedback();
};

