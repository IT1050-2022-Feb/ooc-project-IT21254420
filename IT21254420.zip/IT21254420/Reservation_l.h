#pragma once
#include "Payment.h"
#define SIZE 2

class Reservation_l
{
private:
	Payment *pay[SIZE];
	char reservationID[5];
	char reservationDate[10];
	int labNumber;

public:
	Reservation_l();
	Reservation_l(double pay1, double pay2, char r_ID[], char r_Date[], int labNO);
	void DisplayReservationDetails();
	~Reservation_l();
};

