#pragma once
class Payment
{
protected:
	int payID;
	double amount;
	char payDate[10];

public:
	Payment();
	Payment(double pay);
	Payment(int p_ID, double pAmount, char p_Date[]);
	void Display();
	void DisplayPaymentDetails();
	~Payment();
};

